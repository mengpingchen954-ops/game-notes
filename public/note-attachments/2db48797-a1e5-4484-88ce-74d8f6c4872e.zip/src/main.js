import './style.css';
import { createGame, step, action, STEP } from './simulation.js';
import { createView } from './view.js';
import { createStudy, startAttempt, observeStudy, finishAttempt, studyReport, studyCSV, nextStudyRound, importStudyReport } from './playtest.js';

const studyEnabled = new URLSearchParams(location.search).get('playtest') === '1';
const study = studyEnabled ? createStudy(new URLSearchParams(location.search).get('automation') === '1' ? 'automation' : 'interactive-unverified') : null;

const swordIcon = '<svg viewBox="0 0 32 32" fill="none" aria-hidden="true"><path d="M25 3 27 10 13 24 8 19Z" fill="currentColor"/><path d="m5 17 10 10M10 23l-6 6" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"/></svg>';
document.querySelector('#app').innerHTML = `
  <main id="game" aria-label="飞剑，回来！游戏">
    <canvas id="arena" aria-label="青石庭院。方向键移动，空格投剑或召回。" tabindex="0"></canvas>
    <div class="vignette" aria-hidden="true"></div>
    <header class="topbar">
      <a class="brand" href="#" id="home" aria-label="返回标题">${swordIcon}<span>回锋试炼<small>THE RETURNING BLADE</small></span></a>
      <div class="objective" id="objective" hidden><span class="seal">试</span><span>清除庭院中的敌人<strong id="remaining">0 <em>/ 6</em></strong></span></div>
      <nav aria-label="游戏设置">
        <button id="sound" class="icon-button" aria-label="关闭声音" title="声音"><span>♪</span></button>
        <button id="help" class="icon-button" aria-label="操作说明" title="操作说明">?</button>
        <button id="pause" class="icon-button" aria-label="暂停游戏" title="暂停 · Esc" hidden>Ⅱ</button>
        <button id="restart" class="icon-button" aria-label="重新开始" title="重来 · R" hidden>↻</button>
      </nav>
    </header>
    <section class="intro" id="intro" aria-labelledby="title">
      <div class="intro-content">
        <div class="eyebrow"><span></span> 一座庭院 · 一把飞剑 · 六名对手</div>
        <h1 id="title">飞剑，<br><i>回来！</i><span class="title-seal">回<br>锋</span></h1>
        <p class="intro-lead">去来皆锋，两击破阵。</p>
        <p class="intro-copy">飞剑去回都能伤敌，每次削去一半血。<br>原地收剑，或绕位串起更多对手。</p>
        <div class="sequence"><span><b>01</b> 投剑</span><i>→</i><span><b>02</b> 绕位</span><i>→</i><span><b>03</b> 召回</span></div>
        <fieldset class="appearance"><legend>选择侠客 <span>招式与能力相同</span></legend><button type="button" data-appearance="male" aria-pressed="true">青衫少侠</button><button type="button" data-appearance="female" aria-pressed="false">青衫女侠</button></fieldset>
        <button class="primary start" id="start">拔剑入阵 <span>↗</span></button>
        <div id="study-menu-import" class="study-menu-import" hidden><button type="button" class="secondary" id="study-import-menu">恢复已有试玩记录</button><div id="study-menu-import-panel" class="study-import-panel" hidden><label for="study-import-menu-text">粘贴之前下载的 JSON</label><textarea id="study-import-menu-text" rows="5" placeholder="粘贴 sword-*.json 的完整内容"></textarea><button type="button" class="study-import-apply primary" id="study-import-menu-apply">载入并继续</button></div></div>
        <p class="intro-controls"><span class="desktop-copy">WASD / 方向键移动 · 空格 / 点击投剑与召回</span><span class="touch-copy">左手摇杆移动 · 右手按钮投剑与召回</span></p>
        <p class="study-disclosure" id="study-disclosure" hidden>三局试玩 · 记录仅保留在当前页面，结束后可下载。</p>
      </div>
      <div class="scene-caption"><span>壹 / 青石庭</span><p>不拼出剑快，<br>只看回锋准。</p></div>
    </section>
    <div id="player-health" class="player-health" hidden aria-label="生命值三格"><span>◆</span><span>◆</span><span>◆</span></div>
    <div id="enemy-health" aria-label="敌人血量" hidden></div>
    <div id="toast" class="toast" role="status" aria-live="polite"></div>
    <div id="combat-text" class="combat-text" aria-hidden="true"></div>
    <footer id="play-hud" hidden>
      <div class="blade-status"><div class="blade-icon">${swordIcon}</div><div><span id="sword-state">剑在手中</span><p id="sword-hint">移动决定朝向，按空格投剑</p></div></div>
      <div class="keyboard-hint"><kbd>W A S D</kbd> 移动 <span>·</span> <kbd>SPACE</kbd> 投剑 / 召回 <span>·</span> <kbd>R</kbd> 重来</div>
      <div class="touch-controls"><div id="joystick" aria-label="移动摇杆"><div class="joystick-ring"></div><div id="stick"></div><span>移动</span></div><button id="action" aria-label="投剑或召回">${swordIcon}<span>投剑</span></button></div>
    </footer>
    <input id="study-import" type="file" accept="application/json,.json" hidden>
    <section id="dialog" class="overlay" hidden aria-modal="true" role="dialog" aria-labelledby="dialog-title">
      <div class="dialog-card"><span class="eyebrow" id="dialog-label">回锋试炼</span><h2 id="dialog-title"></h2><div id="dialog-body"></div><div class="dialog-actions"><button class="primary" id="dialog-primary"></button><button class="secondary" id="dialog-secondary">返回标题</button></div></div>
    </section>
    <div id="fatal" class="overlay" hidden role="alert"><div class="dialog-card"><h2>庭院暂时无法打开</h2><p id="fatal-message"></p><button class="primary" onclick="location.reload()">重新加载</button></div></div>
  </main>`;

const $ = id => document.getElementById(id);
let game = createGame(), view, screen = 'menu', muted = false, reduced = matchMedia('(prefers-reduced-motion: reduce)').matches;
let keys = new Set(), joystick = { x: 0, y: 0 }, joystickPointer = null, accumulator = 0, last = performance.now(), hudElapsed = 0, toastUntil = 0, floatUntil = 0;
let context = null, master = null, pauseReturn = 'play', resultDelay = 0, previousSword = '', frames = [], raf, qualityChecked = false;
if (study) {
  document.body.classList.add('study-mode');
  document.querySelector('.intro-copy').innerHTML = '飞剑去回都能伤敌，每次削去一半血。<br>清除庭院中的六名敌人。';
  document.querySelector('.sequence').innerHTML = '<span><b>01</b> 移动</span><i>·</i><span><b>02</b> 投剑</span><i>·</i><span><b>03</b> 召回</span>';
  document.querySelector('.scene-caption p').innerHTML = '清除敌人，<br>完成试炼。';
  $('start').textContent = '开始第 1 局'; $('study-disclosure').hidden = false;
  $('study-menu-import').hidden = false;
  $('home').setAttribute('aria-label', '结束试玩并查看记录');
}

function audioStart() {
  if (!context) {
    const Audio = window.AudioContext || window.webkitAudioContext;
    if (!Audio) return;
    context = new Audio(); master = context.createGain(); master.gain.value = muted ? 0 : .16; master.connect(context.destination);
  }
  if (context.state === 'suspended') context.resume().catch(() => {});
}
function note(frequency, seconds = .12, kind = 'sine', offset = 0, volume = .3, end = frequency) {
  if (!context || muted) return;
  const t = context.currentTime + offset, o = context.createOscillator(), v = context.createGain();
  o.type = kind; o.frequency.setValueAtTime(frequency, t); o.frequency.exponentialRampToValueAtTime(Math.max(20, end), t + seconds);
  v.gain.setValueAtTime(0, t); v.gain.linearRampToValueAtTime(volume, t + .008); v.gain.exponentialRampToValueAtTime(.001, t + seconds);
  o.connect(v); v.connect(master); o.start(t); o.stop(t + seconds + .02); o.onended = () => { o.disconnect(); v.disconnect(); };
}
function playSound(type, combo = 1) {
  if (type === 'throw') note(670, .15, 'triangle', 0, .5, 220);
  if (type === 'recall') note(300, .22, 'sine', 0, .4, 1100);
  if (type === 'kill') { note(440 + combo * 110, .22, 'triangle', 0, .5); note(120, .1, 'sine', 0, .6, 45); }
  if (type === 'hit') { note(540, .1, 'triangle', 0, .4, 330); note(140, .08, 'sine', 0, .3, 65); }
  if (type === 'stick') note(190, .09, 'triangle', 0, .35, 80);
  if (type === 'catch') note(820, .1, 'sine', 0, .18);
  if (type === 'hurt') note(100, .25, 'sawtooth', 0, .25, 35);
  if (type === 'won') [523, 659, 784, 1047].forEach((f, i) => note(f, .7, 'sine', i * .13, .3));
  if (type === 'lost') [220, 174, 130].forEach((f, i) => note(f, .4, 'triangle', i * .15, .2));
}
function clearInput() {
  keys.clear(); joystick = { x: 0, y: 0 }; joystickPointer = null; $('stick').style.transform = 'translate(-50%, -50%)';
}
function announce(message, seconds = 2) { $('toast').textContent = message; $('toast').classList.add('show'); toastUntil = performance.now() + seconds * 1000; }
function floating(message, x, y) {
  const p = view.project(x, y, 2.3); $('combat-text').textContent = message;
  $('combat-text').style.left = `${p.x}px`; $('combat-text').style.top = `${p.y}px`;
  $('combat-text').classList.remove('pop'); void $('combat-text').offsetWidth; $('combat-text').classList.add('pop'); floatUntil = performance.now() + 950;
}
function setScreen(next) {
  screen = next; clearInput(); accumulator = 0;
  $('intro').hidden = next !== 'menu'; $('dialog').hidden = ['menu', 'play', 'settling'].includes(next);
  const gameplay = next !== 'menu';
  for (const id of ['objective', 'play-hud', 'player-health', 'enemy-health', 'pause', 'restart']) $(id).hidden = !gameplay;
  document.body.dataset.screen = next;
  if (next !== 'play') { $('toast').classList.remove('show'); $('combat-text').classList.remove('pop'); }
}
function reset() {
  if (study && ['study-ready', 'study-summary', 'result', 'settling'].includes(screen)) return;
  if (study?.current) finishAttempt(study, game, 'restarted');
  audioStart(); game = createGame(); view.reset(game); previousSword = ''; hudElapsed = 1; resultDelay = 0; frames = [];
  if (study) startAttempt(study, game);
  setScreen('play'); $('arena').focus({ preventScroll: true }); announce('去程、回程都能伤敌。每次半血，两击击败。', 4.5); updateHud();
}
function openPause(help = false) {
  if (['result', 'settling', 'study-ready', 'study-summary'].includes(screen)) return;
  if (screen !== 'pause') pauseReturn = screen === 'menu' ? 'menu' : 'play';
  if (study?.current && screen === 'play') study.current.pauseCount++;
  setScreen('pause');
  $('dialog-label').textContent = help ? '剑诀 · 只需两个操作' : '暂歇片刻'; $('dialog-title').textContent = help ? '去来皆锋，两击破阵。' : '剑，等你回来。';
  $('dialog-body').innerHTML = `<div class="help-rows"><p><b>移动</b><span>WASD / 方向键，或左侧摇杆。<br>移动方向就是下一剑的朝向。</span></p><p><b>动作</b><span>空格 / J / 点击场地，或右侧按钮。<br>按一次投剑，再按一次召回。</span></p><p><b>命中</b><span>去程、回程经过敌人都扣半血，两击击败。<br>每段飞行对同一敌人只伤害一次，盾兵也一样。</span></p><p><b>回锋</b><span>召回时锁定直线，随后可自由移动。<br>红色扇形是敌人即将攻击的区域。</span></p></div><p class="fine-print">回程穿过石柱 · 瞬间回手无伤害 · 受伤后无敌 0.8 秒<br>R 随时重来 · Esc 暂停 / 继续 · 无倒计时</p>`;
  $('dialog-primary').textContent = pauseReturn === 'menu' ? '知道了' : '继续试炼'; $('dialog-primary').focus();
}
function result() {
  if (study) { studyResult(); return; }
  setScreen('result'); const won = game.phase === 'won';
  $('dialog-label').textContent = won ? '青石庭 · 试炼完成' : '青石庭 · 再试一剑';
  $('dialog-title').textContent = won ? '好一个回马剑。' : '剑回来了，你倒了。';
  let advice = '先用去程打掉半血，再让回程经过敌人。红色扇形亮起时，侧向移开。';
  if (game.stats.throws === 0) advice = '移动会改变朝向。按空格投剑，再按一次召回；不用鼠标瞄准。';
  $('dialog-body').innerHTML = `<p class="result-copy">${won ? '去来两道剑锋，敌阵已破。<br>再试一次，能否用更少的投剑清场？' : advice}</p><div class="result-stats"><div><b>${game.stats.kills}<small> / 6</small></b><span>击败敌人</span></div><div><b>${game.stats.throws}</b><span>投剑次数</span></div><div><b>${game.stats.bestCombo}</b><span>单剑最多击败</span></div></div><p class="fine-print">${game.time.toFixed(1)} 秒 · ${game.player.hp} 格余血 · ${game.stats.hits} 次有效命中</p>`;
  $('dialog-primary').textContent = '再来一局 ↗'; $('dialog-primary').focus();
}
function saveStudyAnswer(decision) {
  const row = study.attempts.at(-1);
  if (row && row.round === study.round) {
    row.playerExplanation = $('study-answer')?.value.trim().slice(0, 1000) ?? row.playerExplanation;
    row.replayDecision = decision;
  }
}
function studyResult() {
  setScreen('result');
  $('dialog-label').textContent = `试玩 · 第 ${study.round} 局 / 共 3 局`;
  $('dialog-title').textContent = game.phase === 'won' ? '本局完成。' : '本局结束。';
  const question = study.round === 1 ? '你觉得刚才为什么赢了或输了？' : '这一局和上一局的打法有什么不同？为什么？';
  $('dialog-body').innerHTML = `<p class="result-copy">击败 ${game.stats.kills} / 6 名敌人，剩余 ${game.player.hp} 格血。</p><label class="study-question" for="study-answer">${question}<span>可选，按自己的理解填写。</span></label><textarea id="study-answer" rows="3" maxlength="1000" placeholder="写下你的想法"></textarea>`;
  $('dialog-primary').textContent = study.round < 3 ? `继续第 ${study.round + 1} 局` : '查看三局记录';
  $('dialog-secondary').textContent = '结束试玩'; $('dialog-primary').focus();
}
function showStudyReady(roundNumber) {
  study.round = roundNumber;
  setScreen('study-ready');
  $('dialog-label').textContent = `试玩 · 第 ${roundNumber} 局 / 共 3 局`;
  $('dialog-title').textContent = roundNumber === 3 ? '这次，试试少投几剑。' : `准备第 ${roundNumber} 局。`;
  $('dialog-body').innerHTML = roundNumber === 3
    ? '<p class="result-copy">尝试用更少的投剑清场，打法由你决定。</p><p class="fine-print">敌人、场景和伤害规则与前两局相同。</p>'
    : '<p class="result-copy">继续用自己的方式清除六名敌人。</p><p class="fine-print">这一局不提供额外目标提示。</p>';
  $('dialog-primary').textContent = `开始第 ${roundNumber} 局`; $('dialog-secondary').textContent = '结束试玩'; $('dialog-primary').focus();
}
function startNextStudyRound() {
  saveStudyAnswer('continue');
  const roundNumber = nextStudyRound(study);
  if (roundNumber <= 3) showStudyReady(roundNumber);
  else studySummary();
}
function downloadStudy(kind) {
  const content = kind === 'csv' ? studyCSV(study) : JSON.stringify(studyReport(study), null, 2);
  const blob = new Blob([content], { type: kind === 'csv' ? 'text/csv;charset=utf-8' : 'application/json;charset=utf-8' });
  const url = URL.createObjectURL(blob), a = document.createElement('a');
  a.href = url; a.download = `${study.sessionId}.${kind}`; document.body.append(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}
function applyStudyImport(text, panel) {
  try {
    importStudyReport(study, JSON.parse(text));
    studySummary();
    announce(`已恢复 ${study.attempts.length} 条试玩记录，可以继续第 ${nextStudyRound(study)} 局。`, 4.5);
  } catch (error) {
    panel.hidden = false;
    panel.insertAdjacentHTML('afterbegin', `<p class="study-import-error" role="alert">导入失败：${String(error.message || '文件格式不正确').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]))}</p>`);
  }
}
function studySummary() {
  if (study.current) finishAttempt(study, game, 'abandoned');
  setScreen('study-summary');
  for (const id of ['objective', 'play-hud', 'player-health', 'enemy-health', 'pause', 'restart']) $(id).hidden = true;
  $('dialog-label').textContent = '试玩记录 · 仅当前页面'; $('dialog-title').textContent = '留下这几局的过程。';
  const outcomes = { won: '胜', lost: '败', restarted: '重开', abandoned: '中止' };
  const nextRound = nextStudyRound(study);
  const progress = Math.min(3, nextRound - 1);
  const continueButton = nextRound <= 3 ? `<button class="study-continue secondary" id="study-continue">继续第 ${nextRound} 局</button>` : '';
  $('dialog-body').innerHTML = `<p class="study-progress">已完成 ${progress} / 3 局${nextRound <= 3 ? ` · 下一局是第 ${nextRound} 局` : ' · 三局已完成'}</p><div class="study-table"><table><thead><tr><th>局 / 次</th><th>结果</th><th>投剑</th><th>余血</th><th>秒</th><th>连杀</th></tr></thead><tbody>${study.attempts.map(a => `<tr><td>${a.round} / ${a.attempt}${a.prompted ? '*' : ''}</td><td>${outcomes[a.outcome]}</td><td>${a.throws}</td><td>${a.remainingHealth}</td><td>${a.activeSeconds.toFixed(1)}</td><td>${a.bestCombo}</td></tr>`).join('')}</tbody></table></div><p class="fine-print">* 第三局接受了目标提示，应单独分析。<br>JSON 包含每次投剑与召回的位置；CSV 包含每局战绩和你的文字说明。记录不会上传，关闭或刷新页面后清空。</p><div class="study-summary-actions">${continueButton}<button class="study-csv secondary" id="study-csv">下载 CSV 表格</button><button class="study-import-button secondary" id="study-import-button">导入已有 JSON 记录</button></div><div id="study-import-panel" class="study-import-panel" hidden><label for="study-import-text">粘贴之前下载的 JSON</label><textarea id="study-import-text" rows="5" placeholder="粘贴 sword-*.json 的完整内容"></textarea><button class="study-import-apply primary" id="study-import-apply">载入并继续</button></div>`;
  $('study-csv').addEventListener('click', () => downloadStudy('csv'));
  $('study-import-button').addEventListener('click', () => { $('study-import-panel').hidden = false; $('study-import-text').focus(); });
  $('study-import-apply').addEventListener('click', () => {
    applyStudyImport($('study-import-text').value, $('study-import-panel'));
  });
  $('study-continue')?.addEventListener('click', () => showStudyReady(nextRound));
  $('dialog-primary').textContent = nextRound <= 3 ? '下载完整 JSON 记录' : '下载完整 JSON 记录';
  $('dialog-secondary').textContent = '留在此页'; $('dialog-primary').focus();
}
function updateHud() {
  $('remaining').innerHTML = `${game.stats.kills} <em>/ ${game.enemies.length}</em>`;
  const state = game.sword.mode;
  if (state !== previousSword) {
    previousSword = state;
    const info = {
      held: ['剑在手中', '移动决定朝向 · 按空格投剑', '投剑'],
      outward: ['飞剑离手', '现在就能召回 · 或先绕到另一侧', '召回'],
      stuck: ['飞剑已停', '找好站位 · 按空格直线召回', '召回'],
      returning: ['回锋已定', '杀伤线已锁定 · 你可以继续移动', '回锋中'],
    }[state];
    if (study && state === 'outward') info[1] = '按空格召回飞剑';
    if (study && state === 'stuck') info[1] = '按空格直线召回飞剑';
    $('sword-state').textContent = info[0]; $('sword-hint').textContent = info[1]; $('action').querySelector('span').textContent = info[2];
    document.body.dataset.sword = state;
  }
  $('player-health').setAttribute('aria-label', `生命值 ${game.player.hp} 格`);
  [...$('player-health').children].forEach((e, i) => e.classList.toggle('empty', i >= game.player.hp));
  game.enemies.forEach(e => {
    const bar = $(`enemy-hp-${e.id}`); bar.hidden = !e.hp;
    bar.setAttribute('aria-label', `${e.type === 'guard' ? '盾兵' : '追兵'}：${e.hp * 50}% 血量`);
    bar.classList.toggle('hit', e.flash > 0);
    [...bar.children].forEach((segment, i) => segment.classList.toggle('empty', i >= e.hp));
  });
}
function trigger() { if (screen === 'play') { audioStart(); action(game); if (study) observeStudy(study, game); } }

try { view = createView($('arena')); view.reset(game); }
catch (error) { $('fatal').hidden = false; $('fatal-message').textContent = `无法初始化 WebGL，请使用支持硬件加速的浏览器。${error.message}`; throw error; }
$('enemy-health').innerHTML = game.enemies.map(e => `<div class="enemy-health" id="enemy-hp-${e.id}" role="img"><span></span><span></span></div>`).join('');

$('start').addEventListener('click', reset);
$('restart').addEventListener('click', reset);
$('study-import-menu').addEventListener('click', () => { $('study-menu-import-panel').hidden = false; $('study-import-menu-text').focus(); });
$('study-import-menu-apply').addEventListener('click', () => applyStudyImport($('study-import-menu-text').value, $('study-menu-import-panel')));
$('home').addEventListener('click', e => { e.preventDefault(); if (study && screen !== 'menu') { if (screen === 'result') saveStudyAnswer('stop'); studySummary(); return; } game = createGame(); view.reset(game); setScreen('menu'); $('start').focus(); });
$('sound').addEventListener('click', () => {
  muted = !muted; audioStart(); if (master) master.gain.value = muted ? 0 : .16;
  $('sound').textContent = muted ? '♩' : '♪'; $('sound').setAttribute('aria-label', muted ? '开启声音' : '关闭声音'); $('sound').classList.toggle('muted', muted);
});
$('help').addEventListener('click', () => openPause(true));
$('pause').addEventListener('click', () => { if (screen === 'play') openPause(); else if (screen === 'pause') setScreen(pauseReturn); });
$('dialog-primary').addEventListener('click', () => {
  if (study) {
    if (screen === 'study-summary') { downloadStudy('json'); return; }
    if (screen === 'study-ready') { screen = 'menu'; reset(); return; }
    if (screen === 'result') { if (study.round < 3) startNextStudyRound(); else { saveStudyAnswer('completed'); studySummary(); } return; }
  }
  if (screen === 'result') reset(); else { setScreen(pauseReturn); if (screen === 'play') $('arena').focus(); }
});
$('dialog-secondary').addEventListener('click', () => {
  if (study && screen !== 'menu') { if (screen === 'study-summary') return; if (screen === 'result') saveStudyAnswer('stop'); studySummary(); return; }
  game = createGame(); view.reset(game); setScreen('menu'); $('start').focus();
});
$('study-import').addEventListener('change', async event => {
  const file = event.target.files?.[0];
  event.target.value = '';
  if (!file) return;
  try {
    const imported = JSON.parse(await file.text());
    importStudyReport(study, imported);
    studySummary();
    announce(`已恢复 ${study.attempts.length} 条试玩记录，可以继续第 ${nextStudyRound(study)} 局。`, 4.5);
  } catch (error) {
    $('dialog-body').insertAdjacentHTML('afterbegin', `<p class="study-import-error" role="alert">导入失败：${String(error.message || '文件格式不正确').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]))}</p>`);
  }
});
document.querySelectorAll('[data-appearance]').forEach(button => button.addEventListener('click', () => {
  document.querySelectorAll('[data-appearance]').forEach(b => b.setAttribute('aria-pressed', String(b === button)));
  view.setAppearance(button.dataset.appearance === 'female');
}));
$('arena').addEventListener('pointerdown', e => { if (e.pointerType === 'mouse' && e.button === 0) trigger(); });
$('action').addEventListener('pointerdown', e => { e.preventDefault(); trigger(); });
const movementCodes = ['KeyW', 'KeyA', 'KeyS', 'KeyD', 'ArrowUp', 'ArrowLeft', 'ArrowDown', 'ArrowRight'];
window.addEventListener('keydown', e => {
  if ((e.target instanceof HTMLTextAreaElement || e.target instanceof HTMLInputElement) && e.code !== 'Tab') return;
  if (movementCodes.includes(e.code) && screen === 'play') { e.preventDefault(); keys.add(e.code); }
  if (['Space', 'KeyJ'].includes(e.code) && screen === 'play') { e.preventDefault(); if (!e.repeat) trigger(); }
  if (e.code === 'KeyR' && screen !== 'menu' && !e.repeat) { e.preventDefault(); reset(); }
  if (e.code === 'Escape' && !e.repeat) { if (screen === 'play') openPause(); else if (screen === 'pause') setScreen(pauseReturn); }
  if (e.code === 'Tab' && !$('dialog').hidden) {
    const buttons = [...$('dialog').querySelectorAll('button, textarea')], first = buttons[0], end = buttons.at(-1);
    if (e.shiftKey && document.activeElement === first) { e.preventDefault(); end.focus(); }
    else if (!e.shiftKey && document.activeElement === end) { e.preventDefault(); first.focus(); }
  }
});
window.addEventListener('keyup', e => keys.delete(e.code));
window.addEventListener('blur', () => { clearInput(); if (screen === 'play') openPause(); });
document.addEventListener('visibilitychange', () => { if (document.hidden) { clearInput(); if (screen === 'play') openPause(); } });
function stickMove(e) {
  if (e.pointerId !== joystickPointer) return;
  const r = $('joystick').getBoundingClientRect(), dx = e.clientX - r.left - r.width / 2, dy = e.clientY - r.top - r.height / 2;
  const d = Math.hypot(dx, dy), scale = Math.min(1, 35 / Math.max(1, d));
  joystick = { x: dx * scale / 35, y: dy * scale / 35 };
  $('stick').style.transform = `translate(calc(-50% + ${dx * scale}px), calc(-50% + ${dy * scale}px))`;
}
$('joystick').addEventListener('pointerdown', e => { if (screen !== 'play' || joystickPointer !== null) return; e.preventDefault(); joystickPointer = e.pointerId; $('joystick').setPointerCapture(e.pointerId); stickMove(e); });
$('joystick').addEventListener('pointermove', stickMove);
for (const event of ['pointerup', 'pointercancel', 'lostpointercapture']) $('joystick').addEventListener(event, e => { if (e.pointerId === joystickPointer) { joystickPointer = null; joystick = { x: 0, y: 0 }; $('stick').style.transform = 'translate(-50%, -50%)'; } });
$('arena').addEventListener('webglcontextlost', e => { e.preventDefault(); if (screen === 'play') openPause(); $('fatal-message').textContent = '图形上下文已中断，请重新加载恢复庭院。'; $('fatal').hidden = false; });

function frame(now) {
  const frameMs = now - last, dt = Math.min(frameMs / 1000, .1); last = now;
  if (screen === 'play') {
    accumulator += dt;
    const x = (keys.has('KeyD') || keys.has('ArrowRight') ? 1 : 0) - (keys.has('KeyA') || keys.has('ArrowLeft') ? 1 : 0) + joystick.x;
    const y = (keys.has('KeyS') || keys.has('ArrowDown') ? 1 : 0) - (keys.has('KeyW') || keys.has('ArrowUp') ? 1 : 0) + joystick.y;
    while (accumulator >= STEP) { step(game, { x, y }); if (study) observeStudy(study, game); accumulator -= STEP; }
    for (const e of game.events.splice(0)) {
      view.event(e, reduced); playSound(e.type, e.combo);
      if (e.type === 'kill') floating(e.combo > 1 ? `一剑 · ${e.combo} 破` : '击败！', e.x, e.y);
      if (e.type === 'hit') floating('−50% · 剩半血', e.x, e.y);
      if (e.type === 'hit' || e.type === 'kill' || e.type === 'hurt') updateHud();
      if (e.type === 'hurt') announce('红色区域即将出招，侧向移开。', 2.2);
      if (e.type === 'won' || e.type === 'lost') { if (study) finishAttempt(study, game, e.type); screen = 'settling'; clearInput(); resultDelay = e.type === 'won' ? .9 : .65; updateHud(); }
    }
  } else if (screen === 'settling') { resultDelay -= dt; if (resultDelay <= 0) result(); }
  hudElapsed += dt;
  if (hudElapsed > .08) { updateHud(); hudElapsed = 0; }
  if (now > toastUntil) $('toast').classList.remove('show');
  if (now > floatUntil) $('combat-text').classList.remove('pop');
  const pos = view.project(game.player.x, game.player.y, 2.05);
  $('player-health').style.transform = `translate(${pos.x}px, ${pos.y}px) translate(-50%, -50%)`;
  for (const e of game.enemies) {
    const pos = view.project(e.x, e.y, 2.05);
    $(`enemy-hp-${e.id}`).style.transform = `translate(${pos.x}px, ${pos.y}px) translate(-50%, -50%)`;
  }
  view.render(game, screen === 'settling' && game.phase === 'lost' ? dt * .3 : dt, reduced, screen === 'pause');
  if (screen === 'play') {
    frames.push(frameMs); if (frames.length > 600) frames.shift();
    if (!qualityChecked && frames.length >= 90) {
      qualityChecked = true;
      if (frames.slice(15).reduce((a, b) => a + b, 0) / (frames.length - 15) > 32) view.reduceResolution();
    }
  }
  raf = requestAnimationFrame(frame);
}
setScreen('menu'); raf = requestAnimationFrame(frame);
if (study) window.__study = { report: () => structuredClone(studyReport(study)) };
// Read-only diagnostics allow browser tests to inspect real input results.
window.__sword = { snapshot: () => ({ screen, game: JSON.parse(JSON.stringify(game, (k, v) => v instanceof Set ? [...v] : v)), performance: { frames: frames.length, averageMs: frames.length ? frames.reduce((a, b) => a + b, 0) / frames.length : 0, recentAverageMs: frames.length ? frames.slice(-60).reduce((a, b) => a + b, 0) / Math.min(60, frames.length) : 0, pixelRatio: view.renderer.getPixelRatio(), calls: view.renderer.info.render.calls, triangles: view.renderer.info.render.triangles, geometries: view.renderer.info.memory.geometries, textures: view.renderer.info.memory.textures } }) };
window.addEventListener('pagehide', () => { cancelAnimationFrame(raf); view.dispose(); context?.close(); }, { once: true });
