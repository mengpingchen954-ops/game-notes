export const STEP = 1 / 60;
export const ARENA = { x: 8.2, y: 5.1 };
export const PILLARS = [{ x: -2.7, y: -2.6, r: .48 }, { x: 2.7, y: 2.6, r: .48 }];
export const TUNE = { playerSpeed: 4.4, outwardSpeed: 17, returnSpeed: 22, invulnerable: .8 };
const length = (x, y) => Math.hypot(x, y);
const norm = (x, y) => { const d = length(x, y); return d ? { x: x / d, y: y / d } : { x: 1, y: 0 }; };
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));

export function createGame() {
  const player = { x: -5.7, y: .3, fx: 1, fy: 0, hp: 3, invulnerable: 0, moving: false };
  const enemies = [
    ['chaser', .2, -2], ['chaser', 1, 2.5], ['guard', 3.5, .3],
    ['chaser', -3.5, -4], ['guard', 5.8, -3.4], ['chaser', 6, 3.7],
  ].map(([type, x, y], id) => {
    const dir = norm(player.x - x, player.y - y);
    return { id, type, x, y, fx: dir.x, fy: dir.y, hp: 2, mode: 'chase', timer: 0, flash: 0, deadTime: 0 };
  });
  return {
    phase: 'playing', time: 0, grace: 1.4, player, enemies,
    sword: { mode: 'held', x: player.x, y: player.y, dx: 1, dy: 0, lock: null, origin: null, hit: new Set(), combo: 0 },
    stats: { throws: 0, recalls: 0, hits: 0, kills: 0, bestCombo: 0 }, events: [],
  };
}

function emit(g, type, payload = {}) { g.events.push({ type, ...payload }); }

export function action(g) {
  if (g.phase !== 'playing') return;
  const s = g.sword, p = g.player;
  if (s.mode === 'held') {
    Object.assign(s, { mode: 'outward', x: p.x, y: p.y, dx: p.fx, dy: p.fy, lock: null, origin: null, combo: 0 });
    s.hit.clear();
    g.stats.throws++;
    emit(g, 'throw', { x: p.x, y: p.y });
  } else if (s.mode === 'outward' || s.mode === 'stuck') {
    s.mode = 'returning'; s.lock = { x: p.x, y: p.y }; s.origin = { x: s.x, y: s.y }; s.hit.clear();
    Object.assign(s, { dx: norm(p.x - s.x, p.y - s.y).x, dy: norm(p.x - s.x, p.y - s.y).y });
    g.stats.recalls++;
    emit(g, 'recall', { x: s.x, y: s.y });
  }
}

// Swept intersections keep thin targets hittable at any render frame rate.
export function segmentCircle(ax, ay, bx, by, cx, cy, r) {
  const dx = bx - ax, dy = by - ay, ox = ax - cx, oy = ay - cy;
  const a = dx * dx + dy * dy, c = ox * ox + oy * oy - r * r;
  if (c <= 0) return 0;
  if (a < 1e-12) return null;
  const b = 2 * (ox * dx + oy * dy), discriminant = b * b - 4 * a * c;
  if (discriminant < 0) return null;
  const t = (-b - Math.sqrt(discriminant)) / (2 * a);
  return t >= 0 && t <= 1 ? t : null;
}

function moveBody(body, dx, dy, radius) {
  body.x = clamp(body.x + dx, -ARENA.x + radius, ARENA.x - radius);
  body.y = clamp(body.y + dy, -ARENA.y + radius, ARENA.y - radius);
  for (const o of PILLARS) {
    const x = body.x - o.x, y = body.y - o.y, d = length(x, y), min = radius + o.r;
    if (d < min) { const n = norm(x, y); body.x = o.x + n.x * min; body.y = o.y + n.y * min; }
  }
}

function returnToHand(g) {
  const s = g.sword;
  s.mode = 'held'; s.x = g.player.x; s.y = g.player.y; s.lock = null; s.origin = null;
  emit(g, 'catch', { combo: s.combo });
}

function hitEnemies(g, ax, ay, bx, by) {
  const s = g.sword;
  for (const e of g.enemies) {
    if (!e.hp || s.hit.has(e.id)) continue;
    if (segmentCircle(ax, ay, bx, by, e.x, e.y, .46) === null) continue;
    s.hit.add(e.id); e.hp--; e.flash = .2; g.stats.hits++;
    if (e.hp === 0) {
      e.deadTime = 0; s.combo++; g.stats.kills++;
      g.stats.bestCombo = Math.max(g.stats.bestCombo, s.combo);
      emit(g, 'kill', { x: e.x, y: e.y, combo: s.combo });
    } else emit(g, 'hit', { x: e.x, y: e.y, hp: e.hp });
  }
}

function moveSword(g, dt) {
  const s = g.sword;
  if (s.mode === 'held') { s.x = g.player.x; s.y = g.player.y; return; }
  if (s.mode === 'stuck') return;
  const ax = s.x, ay = s.y;
  if (s.mode === 'outward') {
    const bx = ax + s.dx * TUNE.outwardSpeed * dt, by = ay + s.dy * TUNE.outwardSpeed * dt;
    let t = 1, blocked = false;
    for (const o of PILLARS) {
      const hit = segmentCircle(ax, ay, bx, by, o.x, o.y, o.r);
      if (hit !== null && hit <= t) { t = hit; blocked = true; }
    }
    for (const [a, b, limit] of [[ax, bx, ARENA.x], [ay, by, ARENA.y]]) {
      if (Math.abs(b) >= limit && b !== a) {
        const hit = (Math.sign(b) * limit - a) / (b - a);
        if (hit >= 0 && hit <= t) { t = hit; blocked = true; }
      }
    }
    s.x = ax + (bx - ax) * t; s.y = ay + (by - ay) * t;
    hitEnemies(g, ax, ay, s.x, s.y);
    if (blocked) { s.mode = 'stuck'; emit(g, 'stick', { x: s.x, y: s.y }); }
    return;
  }
  const distance = length(s.lock.x - ax, s.lock.y - ay), travel = Math.min(distance, TUNE.returnSpeed * dt);
  const bx = ax + s.dx * travel, by = ay + s.dy * travel;
  hitEnemies(g, ax, ay, bx, by);
  s.x = bx; s.y = by;
  if (distance <= travel + 1e-8) returnToHand(g);
}

function hurt(g) {
  const p = g.player;
  if (p.invulnerable > 0 || g.phase !== 'playing') return;
  p.hp--; p.invulnerable = TUNE.invulnerable; emit(g, 'hurt', { x: p.x, y: p.y });
}

export function step(g, input = { x: 0, y: 0 }, dt = STEP) {
  if (g.phase !== 'playing') return;
  g.time += dt; g.grace = Math.max(0, g.grace - dt);
  const p = g.player;
  p.invulnerable = Math.max(0, p.invulnerable - dt);
  const magnitude = length(input.x, input.y), direction = norm(input.x, input.y);
  p.moving = magnitude > .08;
  if (p.moving) {
    p.fx = direction.x; p.fy = direction.y;
    moveBody(p, direction.x * Math.min(magnitude, 1) * TUNE.playerSpeed * dt, direction.y * Math.min(magnitude, 1) * TUNE.playerSpeed * dt, .3);
  }
  moveSword(g, dt);
  // Resolve sword damage first so a simultaneous final hit wins.
  if (g.enemies.every(e => !e.hp)) {
    g.phase = 'won'; returnToHand(g); emit(g, 'won'); return;
  }
  for (const e of g.enemies) {
    e.flash = Math.max(0, e.flash - dt);
    if (!e.hp) { e.deadTime += dt; continue; }
    if (g.grace > 0) continue;
    const dx = p.x - e.x, dy = p.y - e.y, distance = length(dx, dy), d = norm(dx, dy);
    if (e.mode === 'chase') {
      if (distance > 1.12) {
        e.fx = d.x; e.fy = d.y;
        const speed = e.type === 'guard' ? .95 : 1.45;
        moveBody(e, d.x * speed * dt, d.y * speed * dt, .36);
        // Small separation keeps silhouettes readable; no collision damage.
        for (const other of g.enemies) {
          if (other.id === e.id || !other.hp) continue;
          const n = norm(e.x - other.x, e.y - other.y);
          if (length(e.x - other.x, e.y - other.y) < .72) moveBody(e, n.x * dt * .6, n.y * dt * .6, .36);
        }
      } else { e.mode = 'windup'; e.timer = e.type === 'guard' ? .8 : .58; emit(g, 'windup', { x: e.x, y: e.y }); }
    } else if (e.mode === 'windup') {
      e.timer -= dt;
      if (e.timer <= 0) { e.mode = 'strike'; e.timer = .18; emit(g, 'strike', { x: e.x, y: e.y }); }
    } else if (e.mode === 'strike') {
      if (e.type === 'guard') moveBody(e, e.fx * dt * 4, e.fy * dt * 4, .36);
      const rx = p.x - e.x, ry = p.y - e.y, rd = length(rx, ry);
      if (rd <= 1.35 && (rd < .3 || (rx * e.fx + ry * e.fy) / rd > .25)) hurt(g);
      e.timer -= dt;
      if (e.timer <= 0) { e.mode = 'recover'; e.timer = .8; }
    } else { e.timer -= dt; if (e.timer <= 0) e.mode = 'chase'; }
  }
  if (p.hp <= 0) { g.phase = 'lost'; emit(g, 'lost'); }
}
