// Observation only: this module never changes combat state or predicts intent.
const point = p => ({ x: p.x, y: p.y });
const round = n => Math.round(n * 1000) / 1000;
export function createStudy(source = 'interactive-unverified') {
  return {
    schema: 1, protocol: 'free-free-fewer-throws-v1', rules: 'two-hits-both-directions-v1', source,
    startedAt: new Date().toISOString(), sessionId: `sword-${Date.now().toString(36)}`,
    condition: 'neutral-instructions-rounds-1-2', round: 1, attempts: [], current: null,
  };
}

export function studyRoundCompleted(study, roundNumber) {
  return study.attempts.some(a => a.round === roundNumber && (a.outcome === 'won' || a.outcome === 'lost'));
}

export function nextStudyRound(study) {
  for (let roundNumber = 1; roundNumber <= 3; roundNumber++) {
    if (!studyRoundCompleted(study, roundNumber)) return roundNumber;
  }
  return 4;
}

export function importStudyReport(study, raw) {
  if (!raw || typeof raw !== 'object' || Array.isArray(raw)) throw new Error('记录必须是 JSON 对象');
  if (raw.schema !== 1 || raw.protocol !== 'free-free-fewer-throws-v1') throw new Error('记录版本或试玩协议不匹配');
  if (!Array.isArray(raw.attempts)) throw new Error('记录缺少 attempts 列表');
  const attempts = raw.attempts.map((a, index) => {
    if (!a || typeof a !== 'object' || !Number.isInteger(a.round) || a.round < 1 || a.round > 3 || !Number.isInteger(a.attempt) || a.attempt < 1) {
      throw new Error(`第 ${index + 1} 条记录的局数或次数字段无效`);
    }
    const numericFields = ['activeSeconds', 'throws', 'recalls', 'hits', 'kills', 'remainingHealth', 'bestCombo', 'distanceMoved', 'pauseCount'];
    if (!['won', 'lost', 'restarted', 'abandoned'].includes(a.outcome) || numericFields.some(field => typeof a[field] !== 'number') || !Array.isArray(a.shots)) {
      throw new Error(`第 ${index + 1} 条记录缺少完整战绩字段`);
    }
    return JSON.parse(JSON.stringify(a));
  });
  const imported = {
    schema: 1,
    protocol: raw.protocol,
    rules: typeof raw.rules === 'string' ? raw.rules : 'two-hits-both-directions-v1',
    source: typeof raw.source === 'string' ? raw.source : 'interactive-unverified',
    startedAt: typeof raw.startedAt === 'string' ? raw.startedAt : new Date().toISOString(),
    sessionId: typeof raw.sessionId === 'string' && raw.sessionId ? raw.sessionId : `sword-${Date.now().toString(36)}`,
    condition: typeof raw.condition === 'string' ? raw.condition : 'neutral-instructions-rounds-1-2',
    round: 1,
    attempts,
    current: null,
  };
  Object.assign(study, imported);
  study.round = nextStudyRound(study);
  return study.round;
}
export function startAttempt(study, game) {
  study.current = {
    round: study.round, attempt: study.attempts.filter(a => a.round === study.round).length + 1,
    prompted: study.round === 3, startTime: game.time, previousPosition: point(game.player),
    previousMode: game.sword.mode, throwsSeen: game.stats.throws, recallsSeen: game.stats.recalls,
    shots: [], activeShot: null, distanceMoved: 0, pauseCount: 0,
  };
}
export function observeStudy(study, game) {
  const a = study.current; if (!a) return;
  const p = point(game.player), distance = Math.hypot(p.x - a.previousPosition.x, p.y - a.previousPosition.y);
  a.distanceMoved += distance;
  if (a.activeShot) {
    a.activeShot.distanceWhileAway += distance;
    if (a.activeShot.recallAt === null) a.activeShot.distanceBeforeRecall += distance;
  }
  if (game.stats.throws > a.throwsSeen) {
    a.activeShot = {
      number: game.stats.throws, thrownAt: game.time, from: p,
      recallAt: null, recallFrom: null, displacementBeforeRecall: null,
      distanceBeforeRecall: 0, distanceWhileAway: 0,
      killsBefore: game.stats.kills, hitsBefore: game.stats.hits, completed: false,
    };
    a.shots.push(a.activeShot);
  }
  if (game.stats.recalls > a.recallsSeen && a.activeShot) {
    a.activeShot.recallAt = game.time; a.activeShot.recallFrom = p;
    a.activeShot.displacementBeforeRecall = Math.hypot(p.x - a.activeShot.from.x, p.y - a.activeShot.from.y);
  }
  if (a.activeShot) {
    a.activeShot.kills = game.stats.kills - a.activeShot.killsBefore;
    a.activeShot.hits = game.stats.hits - a.activeShot.hitsBefore;
    if (game.sword.mode === 'held') {
      a.activeShot.completed = true; a.activeShot.endedAt = game.time; a.activeShot = null;
    }
  }
  a.previousPosition = p; a.previousMode = game.sword.mode;
  a.throwsSeen = game.stats.throws; a.recallsSeen = game.stats.recalls;
}
export function finishAttempt(study, game, outcome) {
  if (!study.current) return null;
  observeStudy(study, game);
  const a = study.current;
  const record = {
    round: a.round, attempt: a.attempt, prompted: a.prompted, outcome,
    activeSeconds: round(game.time - a.startTime), throws: game.stats.throws, recalls: game.stats.recalls,
    hits: game.stats.hits, kills: game.stats.kills, remainingHealth: game.player.hp, bestCombo: game.stats.bestCombo,
    distanceMoved: round(a.distanceMoved), pauseCount: a.pauseCount,
    shots: a.shots.map(({ killsBefore, hitsBefore, ...shot }) => shot),
    playerExplanation: '', replayDecision: null,
  };
  study.attempts.push(record); study.current = null; return record;
}
export function studyReport(study) {
  const { current, ...report } = study;
  return { ...report, exportedAt: new Date().toISOString(), notice: 'Movement is not proof of strategy. Round 3 is prompted. Automated sessions are not human playtest evidence.' };
}
export function studyCSV(study) {
  const quote = value => {
    let text = String(value ?? '');
    if (typeof value === 'string' && /^[\s]*[=+@-]/.test(text)) text = `'${text}`;
    return `"${text.replaceAll('"', '""')}"`;
  };
  const rows = [['session', 'source', 'rules', 'round', 'attempt', 'prompted', 'outcome', 'active_seconds', 'throws', 'recalls', 'hits', 'kills', 'remaining_health', 'best_combo', 'distance_moved', 'pause_count', 'replay_decision', 'player_explanation']];
  for (const a of study.attempts) rows.push([study.sessionId, study.source, study.rules, a.round, a.attempt, a.prompted, a.outcome, a.activeSeconds, a.throws, a.recalls, a.hits, a.kills, a.remainingHealth, a.bestCombo, a.distanceMoved, a.pauseCount, a.replayDecision, a.playerExplanation]);
  return '\uFEFF' + rows.map(row => row.map(quote).join(',')).join('\r\n');
}
