import * as THREE from 'three';
import { mergeGeometries } from 'three/addons/utils/BufferGeometryUtils.js';
import { ARENA, PILLARS } from './simulation.js';

const C = { teal: 0x17665c, dark: 0x203b3b, gold: 0xd3a553, cream: 0xefe6d1, red: 0xb84236, skin: 0xeac6a0 };
const material = (color, extra = {}) => new THREE.MeshStandardMaterial({ color, roughness: .85, flatShading: true, ...extra });
const box = (x, y, z) => new THREE.BoxGeometry(x, y, z);
// Batch only fixed decoration; animated limbs and gameplay objects stay separate.
function batchStatic(group, excluded = new Set()) {
  group.updateWorldMatrix(true, true);
  const inverse = group.matrixWorld.clone().invert(), batches = new Map(), originals = [];
  group.traverse(o => {
    if (!o.isMesh) return;
    for (let p = o; p && p !== group; p = p.parent) if (excluded.has(p)) return;
    const m = o.material, key = [m.type, m.color?.getHex(), m.roughness, m.metalness, m.emissive?.getHex(), m.emissiveIntensity, m.map?.uuid, m.side, o.castShadow].join('/');
    if (!batches.has(key)) batches.set(key, { material: m, shadow: o.castShadow, geometries: [] });
    const geom = o.geometry.index ? o.geometry.toNonIndexed() : o.geometry.clone();
    geom.applyMatrix4(inverse.clone().multiply(o.matrixWorld)); batches.get(key).geometries.push(geom); originals.push(o);
  });
  for (const b of batches.values()) {
    const merged = mergeGeometries(b.geometries, false);
    if (merged) { const m = new THREE.Mesh(merged, b.material); m.castShadow = b.shadow; m.receiveShadow = true; group.add(m); }
    b.geometries.forEach(g => g.dispose());
  }
  originals.forEach(o => { o.removeFromParent(); o.geometry.dispose(); });
}
function mesh(parent, geometry, mat, x = 0, y = 0, z = 0, shadow = false) {
  const m = new THREE.Mesh(geometry, mat); m.position.set(x, y, z); m.castShadow = shadow; m.receiveShadow = true; parent.add(m); return m;
}
function texture(size, draw) {
  const canvas = document.createElement('canvas'); canvas.width = canvas.height = size;
  draw(canvas.getContext('2d'), size);
  const t = new THREE.CanvasTexture(canvas); t.colorSpace = THREE.SRGBColorSpace; t.anisotropy = 4; return t;
}
function textTexture(text, bg, fg) {
  return texture(256, (c, s) => {
    c.fillStyle = bg; c.fillRect(0, 0, s, s); c.strokeStyle = fg; c.lineWidth = 5; c.strokeRect(16, 16, s - 32, s - 32);
    c.fillStyle = fg; c.textAlign = 'center'; c.textBaseline = 'middle'; c.font = 'bold 154px "KaiTi", "STKaiti", serif'; c.fillText(text, s / 2, s / 2 + 7);
  });
}
function floorTexture() {
  return texture(2048, (c, s) => {
    c.fillStyle = '#c6c5ae'; c.fillRect(0, 0, s, s);
    for (let y = 0; y < 12; y++) for (let x = 0; x < 18; x++) {
      const shade = 192 + ((x * 13 + y * 17) % 23);
      c.fillStyle = `rgb(${shade + 14},${shade + 11},${shade - 7})`;
      c.fillRect(x * s / 18 + 2, y * s / 12 + 2, s / 18 - 4, s / 12 - 4);
      c.strokeStyle = '#f4ebd033'; c.lineWidth = 2;
      c.strokeRect(x * s / 18 + 6, y * s / 12 + 6, s / 18 - 12, s / 12 - 12);
    }
    c.strokeStyle = '#827955'; c.lineWidth = 6; c.strokeRect(34, 34, s - 68, s - 68);
    c.strokeStyle = '#9b8a58'; c.lineWidth = 3; c.strokeRect(56, 56, s - 112, s - 112);
    c.save(); c.translate(s / 2, s / 2); c.scale(1, 1.5);
    for (const r of [280, 300, 317]) { c.beginPath(); c.arc(0, 0, r, 0, Math.PI * 2); c.strokeStyle = '#93886065'; c.lineWidth = r === 300 ? 8 : 2; c.stroke(); }
    for (let i = 0; i < 8; i++) {
      c.save(); c.rotate(i * Math.PI / 4); c.fillStyle = '#8e835b65';
      for (let j = 0; j < 3; j++) { if ((i + j) % 3) c.fillRect(-36, 220 + j * 12, 72, 5); else { c.fillRect(-36, 220 + j * 12, 29, 5); c.fillRect(7, 220 + j * 12, 29, 5); } }
      c.restore();
    }
    c.font = '180px "KaiTi", serif'; c.textAlign = 'center'; c.textBaseline = 'middle'; c.fillStyle = '#857c6040'; c.fillText('归', 0, 0); c.restore();
  });
}

function swordObject() {
  const g = new THREE.Group();
  const blade = material(0xe7fff1, { metalness: .5, roughness: .25, emissive: 0x82d9c3, emissiveIntensity: .38 });
  const b = mesh(g, new THREE.CylinderGeometry(0, .095, 1.05, 4), blade, 0, 0, .2); b.rotation.x = Math.PI / 2;
  mesh(g, box(.48, .08, .1), material(C.gold, { metalness: .5 }), 0, 0, -.32);
  mesh(g, box(.075, .085, .3), material(C.dark), 0, 0, -.51);
  const tassel = mesh(g, new THREE.ConeGeometry(.07, .28, 5), material(C.red), 0, 0, -.77); tassel.rotation.x = -Math.PI / 2;
  return g;
}

function character(type, feminine = false) {
  const root = new THREE.Group(), body = new THREE.Group(); root.add(body);
  const hero = type === 'hero', guard = type === 'guard';
  const robe = material(hero ? C.teal : guard ? C.red : 0x626575);
  const trim = material(hero ? C.cream : guard ? C.gold : 0xb9ad95);
  const dark = material(C.dark), skin = material(C.skin), gold = material(C.gold);
  const legs = [];
  for (const x of [-.14, .14]) {
    const leg = mesh(body, box(.16, .32, .22), dark, x, .22, 0, true); legs.push(leg);
    mesh(body, box(.19, .11, .32), dark, x, .085, .06, true);
  }
  mesh(body, new THREE.CylinderGeometry(.22, .39, .57, 8), robe, 0, .59, 0, true);
  mesh(body, new THREE.CylinderGeometry(.29, .23, .39, 8), robe, 0, 1.02, 0, true);
  mesh(body, new THREE.CylinderGeometry(.26, .26, .075, 8), gold, 0, .82, 0, true);
  const lapel = mesh(body, box(.09, .4, .03), trim, -.02, 1.04, .265); lapel.rotation.z = -.45;
  mesh(body, new THREE.SphereGeometry(.225, 10, 8), skin, 0, 1.43, .015, true);
  mesh(body, new THREE.SphereGeometry(.236, 10, 6, 0, Math.PI * 2, 0, Math.PI * .53), dark, 0, 1.45, 0, true);
  mesh(body, new THREE.SphereGeometry(.105, 8, 6), dark, 0, 1.7, -.045, true);
  const band = mesh(body, box(.46, .045, .045), hero ? gold : trim, 0, 1.55, .12);
  band.rotation.x = -.12;
  for (const x of [-.075, .075]) mesh(body, box(.038, .025, .018), dark, x, 1.44, .229);
  const arms = [];
  for (const side of [-1, 1]) {
    const arm = mesh(body, new THREE.CylinderGeometry(.11, .14, .44, 6), robe, side * .34, 1.02, 0, true);
    arm.rotation.z = side * .24; arms.push(arm);
    mesh(body, new THREE.SphereGeometry(.085, 8, 6), skin, side * .39, .8, .015, true);
  }
  const scarf = mesh(body, box(.17, .03, .58), trim, .08, 1.18, -.38, true); scarf.rotation.x = -.35;
  if (hero && feminine) {
    const hair = mesh(body, new THREE.CylinderGeometry(.11, .045, .55, 6), dark, 0, 1.26, -.22, true); hair.rotation.x = -.3;
    mesh(body, new THREE.SphereGeometry(.055, 8, 6), material(C.red), .13, 1.65, -.07);
  }
  if (!hero && !guard) {
    const hat = mesh(body, new THREE.ConeGeometry(.4, .24, 12), material(0x877c61), 0, 1.72, 0, true);
    hat.rotation.z = .08;
    const stick = mesh(body, new THREE.CylinderGeometry(.035, .035, 1.25, 6), dark, .4, .95, .2, true); stick.rotation.x = -.35;
  }
  let shield = null;
  if (guard) {
    shield = new THREE.Group(); shield.position.set(0, .96, .45); body.add(shield);
    const plate = mesh(shield, new THREE.CylinderGeometry(.38, .38, .1, 8), material(0x7b342c), 0, 0, 0, true); plate.rotation.x = Math.PI / 2;
    const rim = mesh(shield, new THREE.TorusGeometry(.35, .033, 5, 8), gold); rim.rotation.z = Math.PI / 8;
    mesh(shield, new THREE.SphereGeometry(.12, 8, 6), gold, 0, 0, .08);
    for (const x of [-.18, .18]) mesh(shield, box(.018, .43, .02), gold, x, 0, .068);
  }
  const heldSword = swordObject(); heldSword.position.set(.4, .9, .38); body.add(heldSword); heldSword.visible = hero;
  batchStatic(body, new Set([...legs, ...arms, scarf, shield, heldSword]));
  body.traverse(o => { if (o.isMesh) o.castShadow = false; });
  const shadow = mesh(root, new THREE.CircleGeometry(.47, 24), new THREE.MeshBasicMaterial({ color: 0x234e3e, transparent: true, opacity: .16, depthWrite: false }), 0, .045, 0);
  shadow.rotation.x = -Math.PI / 2; shadow.scale.set(1, .75, 1);
  return { root, body, arms, legs, scarf, shield, heldSword };
}

function attackFan() {
  const vertices = [];
  for (let i = 0; i < 16; i++) {
    const a = -.99 + i / 16 * 1.98, b = -.99 + (i + 1) / 16 * 1.98;
    vertices.push(0, .035, 0, Math.sin(a) * 1.4, .035, Math.cos(a) * 1.4, Math.sin(b) * 1.4, .035, Math.cos(b) * 1.4);
  }
  const geometry = new THREE.BufferGeometry(); geometry.setAttribute('position', new THREE.Float32BufferAttribute(vertices, 3));
  return new THREE.Mesh(geometry, new THREE.MeshBasicMaterial({ color: C.red, transparent: true, opacity: .22, side: THREE.DoubleSide, depthWrite: false }));
}

export function createView(canvas) {
  const renderer = new THREE.WebGLRenderer({ canvas, antialias: true, alpha: false, powerPreference: 'high-performance' });
  renderer.setPixelRatio(Math.min(devicePixelRatio, 1.6)); renderer.shadowMap.enabled = true; renderer.shadowMap.type = THREE.PCFShadowMap;
  renderer.outputColorSpace = THREE.SRGBColorSpace; renderer.toneMapping = THREE.ACESFilmicToneMapping; renderer.toneMappingExposure = 1.23;
  const scene = new THREE.Scene(); scene.background = new THREE.Color(0xcbd9cb); scene.fog = new THREE.Fog(0xcbd9cb, 33, 80);
  const camera = new THREE.OrthographicCamera(-14, 14, 9, -9, .1, 110);
  camera.position.set(0, 22, 17); camera.lookAt(0, 0, 0);
  scene.add(new THREE.HemisphereLight(0xf8efd9, 0x477478, 2.45));
  const sun = new THREE.DirectionalLight(0xffe5bc, 3.6); sun.position.set(-8, 16, 8); sun.castShadow = true;
  Object.assign(sun.shadow.camera, { left: -12, right: 12, top: 10, bottom: -10, near: 1, far: 40 });
  sun.shadow.mapSize.set(1024, 1024); sun.shadow.bias = -.001; sun.shadow.normalBias = .035; scene.add(sun);
  renderer.shadowMap.autoUpdate = false; renderer.shadowMap.needsUpdate = true;
  const stone = material(0xb7b49c), darkStone = material(0x788e82), gold = material(C.gold), wood = material(0x544c36), teal = material(C.teal);
  const world = new THREE.Group(); scene.add(world);
  mesh(world, box(200, .1, 200), material(0x86b8ad, { roughness: .55, metalness: .15 }), 0, -1.6, 0);
  mesh(world, box(18.2, .55, 12.2), darkStone, 0, -.64, 0);
  mesh(world, box(17.6, .32, 11.6), stone, 0, -.2, 0);
  mesh(world, box(16.9, .12, 10.8), material(0xffffff, { map: floorTexture() }), 0, -.01, 0);
  for (const y of [-5.65, 5.65]) mesh(world, box(17.8, .2, .26), stone, 0, .08, y);
  for (const x of [-8.65, 8.65]) mesh(world, box(.26, .2, 11.6), stone, x, .08, 0);
  // Low rails frame the arena without concealing combat.
  for (const y of [-5.85, 5.85]) for (let x = -8; x <= 8; x += 2) {
    if (y > 0 && Math.abs(x) < 3) continue;
    mesh(world, box(.22, .7, .22), stone, x, .26, y, true);
    mesh(world, new THREE.SphereGeometry(.17, 6, 4), stone, x, .67, y, true);
  }
  for (const x of [-5.5, 5.5]) mesh(world, box(5.5, .15, .18), stone, x, .4, 5.85, true);
  mesh(world, box(16.5, .15, .18), stone, 0, .4, -5.85, true);
  for (let i = 0; i < 3; i++) mesh(world, box(3.5 + i * .5, .17, .6), stone, 0, -.17 - i * .17, 6.1 + i * .53);
  for (const p of PILLARS) {
    mesh(world, new THREE.CylinderGeometry(.63, .68, .2, 8), stone, p.x, .14, p.y, true);
    mesh(world, new THREE.CylinderGeometry(.39, .48, 1.2, 8), material(0x78816c), p.x, .82, p.y, true);
    for (const h of [.37, 1.21]) mesh(world, new THREE.CylinderGeometry(.49, .49, .08, 8), gold, p.x, h, p.y);
    mesh(world, new THREE.CylinderGeometry(.57, .48, .16, 8), stone, p.x, 1.47, p.y, true);
    mesh(world, new THREE.ConeGeometry(.64, .34, 4), teal, p.x, 1.69, p.y, true).rotation.y = Math.PI / 4;
  }
  function pavilion(x, z) {
    const g = new THREE.Group(); g.position.set(x, 0, z); world.add(g);
    mesh(g, box(3.4, .35, 2.6), stone, 0, .1, 0);
    for (const a of [-1.2, 1.2]) for (const b of [-.8, .8]) mesh(g, new THREE.CylinderGeometry(.085, .12, 2.3, 8), material(0x6a4032), a, 1.35, b, true);
    for (let i = 0; i < 3; i++) {
      const roof = mesh(g, new THREE.ConeGeometry(2.65 - i * .46, .57, 4), material(i % 2 ? 0x295954 : 0x35685b), 0, 2.62 + i * .34, 0, true);
      roof.rotation.y = Math.PI / 4; roof.scale.z = .8;
    }
    mesh(g, new THREE.SphereGeometry(.15, 8, 6), gold, 0, 3.65, 0);
    for (const a of [-1, 1]) {
      const lamp = mesh(g, new THREE.SphereGeometry(.19, 8, 8), material(0xf0ba71, { emissive: 0xa04918, emissiveIntensity: .28 }), a, 1.96, .85);
      lamp.scale.y = 1.35;
      mesh(g, new THREE.CylinderGeometry(.015, .015, .3, 5), gold, a, 1.58, .85);
    }
  }
  pavilion(-8.5, -7.4); pavilion(8.5, -7.4);
  // Calligraphy banners and a moon gate make a small, recognisable martial courtyard.
  const gate = new THREE.Group(); gate.position.set(0, 0, -7.15); world.add(gate);
  const ring = mesh(gate, new THREE.TorusGeometry(1.75, .22, 6, 40), stone, 0, 1.5, 0, true);
  mesh(gate, box(5.5, .3, .8), stone, 0, .2, 0);
  for (const x of [-3.25, 3.25]) {
    mesh(world, new THREE.CylinderGeometry(.045, .045, 3.4, 6), wood, x, 1.7, -6.7, true);
    const banner = mesh(world, new THREE.PlaneGeometry(.72, 1.55), material(0xffffff, { map: textTexture(x < 0 ? '回' : '锋', '#205a51', '#f1d99f'), side: THREE.DoubleSide }), x, 2.15, -6.67);
    banner.rotation.y = x < 0 ? .1 : -.1;
  }
  const leaf = material(0x527962), paleLeaf = material(0x758956);
  for (let i = 0; i < 16; i++) {
    const x = (i % 2 ? 1 : -1) * (10.1 + (i % 4) * .75), z = -5.5 + Math.floor(i / 4) * 2.5;
    const h = 2.3 + (i % 3) * .63;
    mesh(world, new THREE.CylinderGeometry(.045, .075, h, 5), leaf, x, h / 2 - 1, z);
    for (let j = 0; j < 2; j++) {
      const cluster = mesh(world, new THREE.IcosahedronGeometry(.75, 0), j ? leaf : paleLeaf, x + (j ? .28 : -.2), h - .8 + j * .3, z);
      cluster.scale.set(1.1, .28, .75); cluster.rotation.z = j ? .3 : -.3;
    }
  }
  for (let i = 0; i < 12; i++) {
    const mountain = mesh(world, new THREE.ConeGeometry(4 + i % 3, 6 + i % 4 * 2, 5), material(i % 2 ? 0x91afa1 : 0xabc1ad), (i - 6) * 6, -1, -24 - i % 3 * 6);
    mountain.rotation.y = i; mountain.scale.z = .55;
  }
  batchStatic(world);
  const hero = character('hero'); scene.add(hero.root);
  let heroModel = hero, feminine = false;
  let enemyModels = [];
  const sword = swordObject(); scene.add(sword);
  const halo = mesh(scene, new THREE.RingGeometry(.44, .5, 40), new THREE.MeshBasicMaterial({ color: 0x5bddb8, side: THREE.DoubleSide, transparent: true, opacity: .8 }), 0, .08, 0); halo.rotation.x = -Math.PI / 2;
  const pointerShape = new THREE.Shape(); pointerShape.moveTo(-.12, 0); pointerShape.lineTo(0, .25); pointerShape.lineTo(.12, 0); pointerShape.closePath();
  const facing = mesh(scene, new THREE.ShapeGeometry(pointerShape), new THREE.MeshBasicMaterial({ color: C.teal, side: THREE.DoubleSide }), 0, .09, 0); facing.rotation.x = -Math.PI / 2;
  const path = new THREE.Line(new THREE.BufferGeometry().setFromPoints([new THREE.Vector3(), new THREE.Vector3()]), new THREE.LineBasicMaterial({ color: 0x32dfb0, transparent: true, opacity: .75 })); scene.add(path);
  const lockRing = mesh(scene, new THREE.RingGeometry(.2, .25, 28), new THREE.MeshBasicMaterial({ color: 0x3bccad, side: THREE.DoubleSide }), 0, .06, 0); lockRing.rotation.x = -Math.PI / 2;
  const trailCount = 18, trailPoints = Array.from({ length: trailCount }, () => new THREE.Vector3());
  const trail = new THREE.Line(new THREE.BufferGeometry().setFromPoints(trailPoints), new THREE.LineBasicMaterial({ color: 0xd1fff0, transparent: true, opacity: .8 })); scene.add(trail);
  let lastSwordMode = 'held', shake = 0, animateTime = 0;
  const particles = [], sparkGeometry = new THREE.OctahedronGeometry(.055), sparkMaterials = [material(0xffd582, { emissive: 0xc36f1a, emissiveIntensity: .8 }), material(0x92f4cf, { emissive: 0x35bd89, emissiveIntensity: .8 }), material(0xe98b78)];
  const petals = [];
  const petalGeo = new THREE.PlaneGeometry(.11, .075), petalMat = new THREE.MeshBasicMaterial({ color: 0xf3c4a2, side: THREE.DoubleSide, transparent: true, opacity: .8 });
  for (let i = 0; i < 30; i++) { const p = mesh(scene, petalGeo, petalMat, (i * 7.1 % 23) - 11.5, 1 + i % 5, (i * 3.2 % 16) - 8); petals.push(p); }

  function resize() {
    const w = canvas.clientWidth, h = canvas.clientHeight, aspect = w / h;
    const halfW = aspect < 1 ? 9.6 : Math.max(11.4, aspect * 7.3), halfH = halfW / aspect;
    Object.assign(camera, { left: -halfW, right: halfW, top: halfH, bottom: -halfH }); camera.updateProjectionMatrix();
    renderer.setSize(w, h, false);
  }
  const observer = new ResizeObserver(resize); observer.observe(canvas); resize();
  function removeModel(model) {
    scene.remove(model.root); model.root.traverse(o => { if (o.isMesh) { o.geometry.dispose(); if (Array.isArray(o.material)) o.material.forEach(m => m.dispose()); else o.material.dispose(); } });
  }
  function setAppearance(value) {
    if (feminine === value) return;
    feminine = value; removeModel(heroModel); heroModel = character('hero', value); scene.add(heroModel.root);
  }
  function reset(g) {
    for (const model of enemyModels) removeModel(model);
    enemyModels = g.enemies.map(e => {
      const model = character(e.type); scene.add(model.root);
      model.fan = attackFan(); model.root.add(model.fan); model.deathAge = 0;
      const ring = mesh(model.root, new THREE.RingGeometry(.43, .48, 24), new THREE.MeshBasicMaterial({ color: e.type === 'guard' ? C.gold : C.red, side: THREE.DoubleSide, transparent: true, opacity: .55 }), 0, .05, 0);
      ring.rotation.x = -Math.PI / 2;
      return model;
    });
    for (const p of particles) scene.remove(p.mesh); particles.length = 0; shake = 0; lastSwordMode = 'held';
    path.visible = lockRing.visible = trail.visible = false;
    heroModel.body.rotation.set(0, 0, 0); heroModel.root.visible = true;
  }
  function event(e, reduced) {
    if (['kill', 'hit', 'hurt', 'stick'].includes(e.type)) {
      const count = e.type === 'kill' ? 15 : 7;
      for (let i = 0; i < count && particles.length < 150; i++) {
        const m = mesh(scene, sparkGeometry, sparkMaterials[e.type === 'hurt' ? 2 : e.type === 'hit' ? 0 : 1], e.x, .85, e.y);
        const angle = i * 2.4;
        particles.push({ mesh: m, vx: Math.cos(angle) * (1 + i % 3), vz: Math.sin(angle) * (1 + i % 3), vy: 1 + i % 4, life: .45 + i % 3 * .09 });
      }
      if (!reduced && (e.type === 'hurt' || e.type === 'kill')) shake = e.type === 'hurt' ? .14 : .055;
    }
  }
  function render(g, dt, reduced = false, paused = false) {
    const delta = paused ? 0 : dt; animateTime += delta;
    const p = g.player;
    heroModel.root.position.set(p.x, 0, p.y); heroModel.root.rotation.y = Math.atan2(p.fx, p.fy);
    heroModel.root.visible = reduced || p.invulnerable <= 0 || Math.floor(g.time * 5) % 2 === 0;
    heroModel.body.position.y = p.moving && g.phase === 'playing' ? Math.abs(Math.sin(g.time * 14)) * .055 : Math.sin(animateTime * 2) * .012;
    heroModel.body.rotation.z = g.phase === 'lost' ? -1.25 : 0;
    heroModel.legs.forEach((l, i) => l.rotation.x = p.moving && g.phase === 'playing' ? Math.sin(g.time * 14 + i * Math.PI) * .42 : 0);
    heroModel.scarf.rotation.y = Math.sin(animateTime * 4) * .15;
    heroModel.heldSword.visible = g.sword.mode === 'held';
    heroModel.arms[1].rotation.x = g.sword.mode !== 'held' ? -.65 : -.1;
    halo.position.set(p.x, .08, p.y); halo.visible = g.phase !== 'lost';
    facing.position.set(p.x + p.fx * .75, .09, p.y + p.fy * .75); facing.rotation.z = Math.atan2(-p.fx, -p.fy); facing.visible = g.phase === 'playing';
    g.enemies.forEach((e, i) => {
      const m = enemyModels[i]; if (!m) return;
      m.root.position.set(e.x, 0, e.y); m.root.rotation.y = Math.atan2(e.fx, e.fy);
      if (!e.hp) m.deathAge += delta;
      m.root.visible = e.hp > 0 || m.deathAge < .75;
      m.body.rotation.x = e.hp ? (e.mode === 'windup' ? -.15 : 0) : Math.min(1.5, m.deathAge * 6);
      m.body.position.y = e.hp ? (e.mode === 'chase' ? Math.abs(Math.sin(g.time * 9 + i)) * .03 : 0) : -.1;
      m.fan.visible = e.hp > 0 && (e.mode === 'windup' || e.mode === 'strike');
      m.fan.material.opacity = e.mode === 'strike' ? .66 : .18 + (.8 - e.timer) * .25;
      m.arms.forEach(a => a.rotation.x = e.mode === 'windup' ? -1 : e.mode === 'strike' ? -1.5 : -.15);
      if (m.shield) m.shield.scale.setScalar(e.flash > 0 ? 1.15 : 1);
    });
    const s = g.sword;
    sword.visible = s.mode !== 'held'; sword.position.set(s.x, 1.05, s.y); sword.rotation.y = Math.atan2(s.dx, s.dy);
    sword.rotation.z = s.mode === 'stuck' ? .16 : 0;
    path.visible = lockRing.visible = s.mode === 'returning';
    if (path.visible) {
      const a = path.geometry.attributes.position;
      a.setXYZ(0, s.origin.x, .13, s.origin.y); a.setXYZ(1, s.lock.x, .13, s.lock.y); a.needsUpdate = true; path.geometry.computeBoundingSphere();
      lockRing.position.set(s.lock.x, .08, s.lock.y);
    }
    trail.visible = s.mode === 'outward' || s.mode === 'returning';
    if (trail.visible) {
      if (lastSwordMode !== s.mode) trailPoints.forEach(v => v.set(s.x, 1.05, s.y));
      for (let i = trailCount - 1; i > 0; i--) trailPoints[i].copy(trailPoints[i - 1]);
      trailPoints[0].copy(sword.position);
      const a = trail.geometry.attributes.position; trailPoints.forEach((v, i) => a.setXYZ(i, v.x, v.y, v.z)); a.needsUpdate = true; trail.geometry.computeBoundingSphere();
    }
    lastSwordMode = s.mode;
    for (let i = particles.length - 1; i >= 0; i--) {
      const q = particles[i]; q.life -= delta;
      q.mesh.position.x += q.vx * delta; q.mesh.position.z += q.vz * delta; q.mesh.position.y += q.vy * delta; q.vy -= delta * 10;
      q.mesh.scale.setScalar(Math.max(0, q.life * 2)); q.mesh.rotation.x += delta * 4;
      if (q.life <= 0) { scene.remove(q.mesh); particles.splice(i, 1); }
    }
    if (!reduced) for (const petal of petals) {
      petal.position.x += delta * .26; petal.position.y -= delta * .13; petal.rotation.x += delta * .8; petal.rotation.z += delta * .6;
      if (petal.position.y < -.7) { petal.position.y = 5; petal.position.x -= 8; }
    }
    if (shake > 0) { camera.position.x = Math.sin(animateTime * 89) * shake; shake = Math.max(0, shake - delta); } else camera.position.x = 0;
    renderer.render(scene, camera);
  }
  function project(x, y, height = 2.05) {
    const v = new THREE.Vector3(x, height, y).project(camera);
    return { x: (v.x * .5 + .5) * canvas.clientWidth, y: (-v.y * .5 + .5) * canvas.clientHeight };
  }
  function dispose() {
    observer.disconnect();
    const geometries = new Set(), materials = new Set(), textures = new Set();
    scene.traverse(o => { if (o.geometry) geometries.add(o.geometry); for (const m of o.material ? [].concat(o.material) : []) { materials.add(m); if (m.map) textures.add(m.map); } });
    for (const x of geometries) x.dispose(); for (const x of materials) x.dispose(); for (const x of textures) x.dispose(); renderer.dispose();
  }
  function reduceResolution() { renderer.setPixelRatio(.85); resize(); }
  return { render, reset, event, setAppearance, project, dispose, renderer, reduceResolution };
}
