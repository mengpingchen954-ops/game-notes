import test from 'node:test';
import assert from 'node:assert/strict';
import { createGame, action, step, STEP, ARENA, TUNE, segmentCircle } from '../src/simulation.js';

function enemy(id, x, y, type = 'chaser', fx = 1, fy = 0) {
  return { id, x, y, type, fx, fy, hp: 2, mode: 'chase', timer: 0, flash: 0, deadTime: 0 };
}
function fixture(enemies = [enemy(0, 0, 0)]) {
  const g = createGame(); g.grace = 999; g.player.x = -4; g.player.y = 0; g.enemies = enemies; return g;
}
function advance(g, seconds, input = { x: 0, y: 0 }) { for (let i = 0; i < Math.ceil(seconds / STEP); i++) step(g, input); }
function launchReturn(g, from, to) {
  Object.assign(g.player, { x: to.x, y: to.y });
  Object.assign(g.sword, { mode: 'stuck', x: from.x, y: from.y }); action(g);
}

test('one action key throws, recalls early, ignores repeat on return, never creates a second sword', () => {
  const g = fixture(); action(g); assert.equal(g.sword.mode, 'outward');
  advance(g, .1); const from = { x: g.sword.x, y: g.sword.y }; action(g);
  assert.equal(g.sword.mode, 'returning'); assert.deepEqual(g.sword.origin, from);
  action(g); assert.equal(g.stats.throws, 1); assert.equal(g.stats.recalls, 1);
  advance(g, .2); assert.equal(g.sword.mode, 'held'); action(g); assert.equal(g.stats.throws, 2);
});
test('stationary outbound removes half health; return kills overlapping enemies with the second hit', () => {
  const g = fixture([enemy(0, 0, 0), enemy(1, 0, 0), enemy(2, 0, 4)]);
  action(g); advance(g, .45); assert.equal(g.stats.kills, 0); assert.ok(g.sword.x > 0);
  assert.equal(g.enemies[0].hp, 1); assert.equal(g.enemies[1].hp, 1); assert.equal(g.enemies[2].hp, 2);
  action(g); advance(g, .6); assert.equal(g.stats.kills, 2); assert.equal(g.sword.hit.size, 2);
  assert.equal(g.events.filter(e => e.type === 'kill').length, 2);
  assert.equal(g.stats.hits, 4);
});
test('guards take half damage from both front and back', () => {
  const g = fixture([enemy(0, 0, 0, 'guard', 1, 0), enemy(1, 5, 4)]);
  launchReturn(g, { x: 4, y: 0 }, { x: -4, y: 0 }); advance(g, .5);
  assert.equal(g.enemies[0].hp, 1); assert.equal(g.stats.hits, 1); assert.equal(g.sword.mode, 'held');
  launchReturn(g, { x: -4, y: 0 }, { x: 4, y: 0 }); advance(g, .5); assert.equal(g.enemies[0].hp, 0);
});
test('turning a shield no longer grants immunity', () => {
  const g = fixture([enemy(0, 0, 0, 'guard', 1, 0)]);
  launchReturn(g, { x: -4, y: 0 }, { x: 4, y: 0 });
  g.enemies[0].fx = -1; advance(g, .5); assert.equal(g.enemies[0].hp, 1);
  assert.equal(g.stats.hits, 1);
});
test('return locks the point; final teleport to moving player does not harm intervening enemies', () => {
  const g = fixture([enemy(0, -4, 1), enemy(1, 5, 4)]);
  launchReturn(g, { x: 4, y: 0 }, { x: -4, y: 0 });
  step(g, { x: 0, y: 1 }); assert.deepEqual(g.sword.lock, { x: -4, y: 0 }); assert.equal(g.sword.y, 0);
  advance(g, .5, { x: 0, y: 1 }); assert.equal(g.sword.mode, 'held'); assert.equal(g.stats.kills, 0);
  assert.equal(g.stats.hits, 0); assert.equal(g.enemies[0].hp, 2);
  assert.equal(g.sword.y, g.player.y);
});
test('outbound stops on arena boundary and pillars; return can exit the pillar without becoming stuck', () => {
  const g = fixture([enemy(0, 0, 4)]); action(g); advance(g, 1);
  assert.equal(g.sword.mode, 'stuck'); assert.equal(g.sword.x, ARENA.x);
  action(g); advance(g, .7); assert.equal(g.sword.mode, 'held');
  Object.assign(g.player, { x: -5, y: -2.6, fx: 1, fy: 0 }); action(g); advance(g, .2);
  assert.equal(g.sword.mode, 'stuck'); assert.ok(Math.abs(g.sword.x + 3.18) < .001);
  action(g); advance(g, .2); assert.equal(g.sword.mode, 'held');
});
test('multiple simultaneous attacks remove one heart; invulnerability lasts .8 seconds', () => {
  const g = fixture([enemy(0, -4, -.5, 'chaser', 0, 1), enemy(1, -4, -.5, 'chaser', 0, 1)]);
  g.grace = 0; for (const e of g.enemies) { e.mode = 'strike'; e.timer = 10; }
  step(g); assert.equal(g.player.hp, 2); assert.equal(g.player.invulnerable, TUNE.invulnerable);
  advance(g, .76); assert.equal(g.player.hp, 2); advance(g, .07); assert.equal(g.player.hp, 1);
});
test('attack windup locks facing; collision during chase does not bypass warning', () => {
  const g = fixture([enemy(0, -4, -.8, 'chaser', 0, 1)]); g.grace = 0;
  step(g); assert.equal(g.enemies[0].mode, 'windup'); assert.equal(g.player.hp, 3);
  Object.assign(g.player, { x: -5, y: -.8 }); step(g);
  assert.equal(g.enemies[0].fx, 0); assert.equal(g.enemies[0].fy, 1); assert.equal(g.player.hp, 3);
});
test('last enemy dies in same step as lethal attack: victory wins and sword returns', () => {
  const g = fixture([enemy(0, -4, -.3, 'chaser', 0, 1)]); g.grace = 0; g.player.hp = 1;
  g.enemies[0].mode = 'strike'; g.enemies[0].timer = 1; g.enemies[0].hp = 1;
  launchReturn(g, { x: -4, y: -.6 }, { x: -4, y: 0 }); step(g);
  assert.equal(g.phase, 'won'); assert.equal(g.player.hp, 1); assert.equal(g.sword.mode, 'held');
  advance(g, 3); assert.equal(g.player.hp, 1);
});
test('lethal attack loses; actions stop after result; fresh state resets all gameplay fields', () => {
  const g = fixture([enemy(0, -4, -.5, 'chaser', 0, 1)]); g.grace = 0; g.player.hp = 1;
  g.enemies[0].mode = 'strike'; g.enemies[0].timer = 1; step(g); assert.equal(g.phase, 'lost');
  action(g); assert.equal(g.stats.throws, 0);
  const fresh = createGame(); assert.equal(fresh.player.hp, 3); assert.equal(fresh.sword.mode, 'held');
  assert.equal(fresh.enemies.filter(e => e.hp).length, 6); assert.equal(fresh.time, 0); assert.deepEqual(fresh.events, []);
  assert.ok(fresh.enemies.every(e => e.hp === 2)); assert.equal(fresh.stats.hits, 0);
});
test('same fixed-step input produces identical outcomes', () => {
  function play() { const g = createGame(); for (let i = 0; i < 360; i++) { if (i % 42 === 0) action(g); step(g, { x: Math.sin(i / 70), y: Math.cos(i / 90) }); } return JSON.stringify(g); }
  assert.equal(play(), play());
});
test('swept collision catches a target crossed between frames', () => {
  assert.ok(segmentCircle(-5, 0, 5, 0, 0, 0, .4) !== null);
  assert.equal(segmentCircle(-5, 2, 5, 2, 0, 0, .4), null);
});
test('only one hit per enemy per recall even when the target re-enters the path', () => {
  const g = fixture([enemy(0, 0, 0, 'guard', -1, 0), enemy(1, 5, 4)]);
  launchReturn(g, { x: -4, y: 0 }, { x: 4, y: 0 }); advance(g, .18);
  assert.equal(g.stats.hits, 1);
  g.enemies[0].x = g.sword.x + .1; g.enemies[0].fx = 1;
  step(g); assert.equal(g.enemies[0].hp, 1); assert.equal(g.stats.kills, 0);
});
test('outbound overlap or re-entry cannot apply multiple hits in the same leg', () => {
  const g = fixture([enemy(0, 0, 0), enemy(1, 5, 4)]); action(g); advance(g, .23);
  assert.equal(g.enemies[0].hp, 1);
  for (let i = 0; i < 8; i++) { g.enemies[0].x = g.sword.x + .05; step(g); }
  assert.equal(g.enemies[0].hp, 1); assert.equal(g.stats.hits, 1);
});
test('separate throws can finish an enemy even when the first return misses', () => {
  const g = fixture([enemy(0, 0, 0), enemy(1, 5, 4)]);
  action(g); advance(g, .4); assert.equal(g.enemies[0].hp, 1);
  g.player.y = 3; action(g); advance(g, .5); assert.equal(g.enemies[0].hp, 1);
  Object.assign(g.player, { x: -4, y: 0, fx: 1, fy: 0 }); action(g); advance(g, .3);
  assert.equal(g.enemies[0].hp, 0); assert.equal(g.stats.kills, 1);
});
test('outbound damage stops at pillars instead of hitting enemies beyond them', () => {
  const g = fixture([enemy(0, -2, -2.6)]);
  Object.assign(g.player, { x: -5, y: -2.6, fx: 1, fy: 0 }); action(g); advance(g, .4);
  assert.equal(g.sword.mode, 'stuck'); assert.equal(g.enemies[0].hp, 2); assert.equal(g.stats.hits, 0);
});
test('no countdown or time-based loss', () => {
  const g = fixture([enemy(0, 5, 4)]); advance(g, 65); assert.equal(g.phase, 'playing');
});
