import test from 'node:test';
import assert from 'node:assert/strict';
import { createGame, step, action, STEP } from '../src/simulation.js';
import { createStudy, startAttempt, observeStudy, finishAttempt, studyReport, studyCSV, nextStudyRound, importStudyReport } from '../src/playtest.js';

test('study records resume the first unfinished round and preserve imported attempts', () => {
  const study = createStudy('interactive-unverified');
  const imported = { schema: 1, protocol: 'free-free-fewer-throws-v1', rules: 'two-hits-both-directions-v1', source: 'interactive-unverified', sessionId: 'sword-test', attempts: [{ round: 1, attempt: 1, prompted: false, outcome: 'won', activeSeconds: 19.7, throws: 4, recalls: 4, hits: 12, kills: 6, remainingHealth: 3, bestCombo: 2, distanceMoved: 44.3, pauseCount: 0, shots: [] }] };
  assert.equal(importStudyReport(study, imported), 2);
  assert.equal(study.attempts[0].outcome, 'won');
  assert.equal(nextStudyRound(study), 2);
  study.attempts.push({ round: 2, attempt: 1, outcome: 'abandoned' });
  assert.equal(nextStudyRound(study), 2);
  study.attempts.push({ round: 2, attempt: 2, outcome: 'lost' });
  assert.equal(nextStudyRound(study), 3);
  study.attempts.push({ round: 3, attempt: 1, outcome: 'won' });
  assert.equal(nextStudyRound(study), 4);
});

test('recording is observational and does not change simulation outcomes', () => {
  const a = createGame(), b = createGame(), study = createStudy('automation'); startAttempt(study, b);
  for (let i = 0; i < 260; i++) {
    if (i % 30 === 0) { action(a); action(b); observeStudy(study, b); }
    const input = { x: Math.sin(i / 50), y: Math.cos(i / 60) };
    step(a, input); step(b, input); observeStudy(study, b);
  }
  assert.equal(JSON.stringify(a), JSON.stringify(b));
});
test('stationary flight records zero repositioning and correct hit/kill totals', () => {
  const g = createGame(), study = createStudy('automation'); g.grace = 999; startAttempt(study, g);
  action(g); observeStudy(study, g);
  for (let i = 0; i < 45; i++) { step(g); observeStudy(study, g); }
  action(g); observeStudy(study, g);
  for (let i = 0; i < 50; i++) { step(g); observeStudy(study, g); }
  const row = finishAttempt(study, g, 'restarted');
  assert.equal(row.shots.length, 1); assert.equal(row.shots[0].distanceBeforeRecall, 0);
  assert.equal(row.shots[0].displacementBeforeRecall, 0); assert.equal(row.shots[0].hits, 2);
  assert.equal(row.shots[0].kills, 1); assert.equal(row.shots[0].completed, true);
  assert.equal(row.throws, 1); assert.equal(row.remainingHealth, 3);
  assert.equal(finishAttempt(study, g, 'restarted'), null); assert.equal(study.attempts.length, 1);
});
test('movement before recall is distinguished from movement after path locks', () => {
  const g = createGame(), study = createStudy('automation'); g.grace = 999; startAttempt(study, g);
  action(g); observeStudy(study, g);
  for (let i = 0; i < 20; i++) { step(g, { x: 0, y: 1 }); observeStudy(study, g); }
  action(g); observeStudy(study, g);
  const shot = study.current.activeShot, before = shot.distanceBeforeRecall;
  assert.ok(before > 1); assert.ok(Math.abs(shot.displacementBeforeRecall - before) < .001);
  for (let i = 0; i < 10; i++) { step(g, { x: 0, y: -1 }); observeStudy(study, g); }
  assert.equal(shot.distanceBeforeRecall, before); assert.ok(shot.distanceWhileAway > before);
});
test('restarts stay in same round, prompted round is separately tagged, no fake records', () => {
  const study = createStudy('automation'); assert.equal(study.attempts.length, 0);
  startAttempt(study, createGame()); finishAttempt(study, createGame(), 'restarted');
  startAttempt(study, createGame()); assert.equal(study.current.attempt, 2); assert.equal(study.current.round, 1);
  finishAttempt(study, createGame(), 'abandoned'); study.round = 3; startAttempt(study, createGame());
  const row = finishAttempt(study, createGame(), 'lost'); assert.equal(row.prompted, true);
  assert.equal(studyReport(study).source, 'automation'); assert.equal('current' in studyReport(study), false);
});
test('CSV preserves multiline notes and neutralizes spreadsheet formulas', () => {
  const study = createStudy('automation'); const g = createGame(); startAttempt(study, g);
  const row = finishAttempt(study, g, 'lost'); row.playerExplanation = '=1+1\n"note",why';
  const csv = studyCSV(study); assert.ok(csv.startsWith('\uFEFF'));
  assert.ok(csv.includes('"\'=1+1\n""note"",why"'));
});
