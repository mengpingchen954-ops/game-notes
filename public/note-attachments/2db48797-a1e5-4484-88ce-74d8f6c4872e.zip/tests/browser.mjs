import { chromium } from 'playwright';
import assert from 'node:assert/strict';
import { mkdir, writeFile } from 'node:fs/promises';

await mkdir('artifacts', { recursive: true });
const browser = await chromium.launch({ headless: true });
const errors = [], results = [];
function observe(page) {
  page.on('pageerror', e => errors.push(e.message));
  page.on('console', e => { if (e.type() === 'error') errors.push(e.text()); });
}
const page = await browser.newPage({ viewport: { width: 1440, height: 900 } }); observe(page);
const snapshot = () => page.evaluate(() => window.__sword.snapshot());
async function move(key, ms) { await page.keyboard.down(key); await page.waitForTimeout(ms); await page.keyboard.up(key); }
try {
  await page.goto('http://127.0.0.1:5188/'); await page.waitForFunction(() => window.__sword);
  await page.screenshot({ path: 'artifacts/title.png' });
  await page.getByRole('button', { name: '青衫女侠', exact: true }).click();
  assert.equal(await page.getByRole('button', { name: '青衫女侠', exact: true }).getAttribute('aria-pressed'), 'true');
  await page.getByRole('button', { name: '拔剑入阵' }).click();
  await page.keyboard.press('Space');
  await page.waitForFunction(() => window.__sword.snapshot().game.enemies[2].hp === 1);
  assert.equal(await page.locator('#enemy-hp-2 .empty').count(), 1, 'first hit removes exactly one visible health segment');
  await page.screenshot({ path: 'artifacts/half-health.png' });
  await page.keyboard.press('Space');
  await page.waitForTimeout(650);
  let state = await snapshot(); assert.equal(state.game.enemies[2].hp, 0, 'outbound half damage plus return half damage defeats initial guard');
  results.push('Stationary throw removes half health visibly; return delivers the second hit and defeats the guard.');
  await page.keyboard.press('Escape'); const paused = (await snapshot()).game.time;
  await page.waitForTimeout(300); assert.equal((await snapshot()).game.time, paused);
  await page.keyboard.press('Escape');
  await page.keyboard.press('r'); state = await snapshot(); assert.equal(state.game.stats.kills, 0); assert.equal(state.game.player.hp, 3);
  results.push('Pause freezes simulation; R restores all six enemies and three hearts.');
  await page.screenshot({ path: 'artifacts/play.png' });

  // Drive only actual keyboard controls. Diagnostics are read-only; no game-state injection.
  for (let turn = 0; turn < 130; turn++) {
    state = await snapshot(); const g = state.game;
    if (g.phase !== 'playing') break;
    const p = g.player, nearest = g.enemies.filter(e => e.hp).sort((a, b) => Math.hypot(a.x - p.x, a.y - p.y) - Math.hypot(b.x - p.x, b.y - p.y))[0];
    const dx = nearest.x - p.x, dy = nearest.y - p.y, d = Math.hypot(dx, dy);
    if (g.sword.mode === 'held') {
      if (d < 1.45 && ['windup', 'strike'].includes(nearest.mode)) {
        await move(Math.abs(dx) > Math.abs(dy) ? (dx > 0 ? 'a' : 'd') : (dy > 0 ? 'w' : 's'), 190); continue;
      }
      const horizontal = Math.abs(dx) > Math.abs(dy), offset = horizontal ? dy : dx;
      if (Math.abs(offset) > .28) {
        await move(horizontal ? (dy > 0 ? 's' : 'w') : (dx > 0 ? 'd' : 'a'), Math.min(160, Math.max(32, Math.abs(offset) / 4.4 * 600)));
      } else {
        await move(horizontal ? (dx > 0 ? 'd' : 'a') : (dy > 0 ? 's' : 'w'), 22);
        await page.keyboard.press('Space');
        await page.waitForTimeout(Math.min(750, Math.max(120, (d + .85) / 17 * 1000)));
        await page.keyboard.press('Space');
      }
    } else if (g.sword.mode === 'stuck' || g.sword.mode === 'outward') {
      await page.keyboard.press('Space');
    } else if (d < 2) {
      await move(Math.abs(dx) > Math.abs(dy) ? (dx > 0 ? 'a' : 'd') : (dy > 0 ? 'w' : 's'), 100);
    } else await page.waitForTimeout(100);
  }
  state = await snapshot(); console.log('Keyboard playthrough:', state.game.phase, state.game.stats, state.game.player.hp);
  await page.waitForTimeout(1200); await page.screenshot({ path: 'artifacts/result.png' });
  assert.equal(state.game.phase, 'won', 'keyboard-driven playthrough must win');
  results.push(`Keyboard-only clear: ${state.game.stats.recalls} recalls, ${state.game.player.hp} health remaining.`);
  const performance = state.performance;
  await page.getByRole('button', { name: '再来一局' }).click();
  await page.waitForFunction(() => window.__sword.snapshot().screen === 'result', { timeout: 30000 });
  assert.equal((await snapshot()).game.phase, 'lost');
  await page.screenshot({ path: 'artifacts/defeat.png' });
  const started = Date.now(); await page.keyboard.press('r');
  assert.equal((await snapshot()).game.player.hp, 3); assert.ok(Date.now() - started < 3000);
  results.push('Idle play loses; failure restart is playable within three seconds.');
  await page.keyboard.press('Escape');

  const mobile = await browser.newPage({ viewport: { width: 390, height: 844 }, isMobile: true, hasTouch: true, deviceScaleFactor: 1 }); observe(mobile);
  await mobile.goto('http://127.0.0.1:5188/'); await mobile.waitForFunction(() => window.__sword);
  await mobile.screenshot({ path: 'artifacts/mobile-title.png' });
  await mobile.getByRole('button', { name: '拔剑入阵' }).tap();
  const before = await mobile.evaluate(() => window.__sword.snapshot().game.player.x);
  const joystick = await mobile.locator('#joystick').boundingBox();
  const touch = await mobile.context().newCDPSession(mobile);
  await touch.send('Input.dispatchTouchEvent', { type: 'touchStart', touchPoints: [{ x: joystick.x + joystick.width / 2, y: joystick.y + joystick.height / 2 }] });
  await touch.send('Input.dispatchTouchEvent', { type: 'touchMove', touchPoints: [{ x: joystick.x + joystick.width / 2 + 33, y: joystick.y + joystick.height / 2 }] });
  await mobile.waitForTimeout(250);
  await touch.send('Input.dispatchTouchEvent', { type: 'touchEnd', touchPoints: [] });
  const after = await mobile.evaluate(() => window.__sword.snapshot().game.player.x); assert.ok(after > before);
  await mobile.getByRole('button', { name: '投剑或召回' }).tap();
  await mobile.waitForTimeout(250); await mobile.getByRole('button', { name: '投剑或召回' }).tap();
  assert.equal(await mobile.evaluate(() => window.__sword.snapshot().game.stats.recalls), 1);
  await mobile.screenshot({ path: 'artifacts/mobile-play.png' });
  assert.equal(await mobile.evaluate(() => document.documentElement.scrollWidth > innerWidth), false);
  results.push('390×844 mobile: joystick movement, touch throw/recall, no page overflow.');
  await mobile.getByRole('button', { name: '暂停游戏' }).tap();
  await mobile.setViewportSize({ width: 844, height: 390 }); await mobile.screenshot({ path: 'artifacts/mobile-landscape.png' });
  assert.equal(await mobile.evaluate(() => document.documentElement.scrollWidth > innerWidth), false);
  await page.keyboard.press('r'); await page.waitForTimeout(150);
  const memoryBefore = (await snapshot()).performance;
  for (let i = 0; i < 10; i++) { await page.keyboard.press('Space'); await page.waitForTimeout(50); await page.keyboard.press('r'); await page.waitForTimeout(60); }
  const memoryAfter = (await snapshot()).performance;
  assert.equal(memoryAfter.geometries, memoryBefore.geometries);
  assert.equal(memoryAfter.textures, memoryBefore.textures);
  results.push('Ten restarts leave GPU geometry and texture counts unchanged.');
  assert.deepEqual(errors, []);
  results.push('No browser JavaScript or console errors.');
  await writeFile('artifacts/browser-results.json', JSON.stringify({ results, performance, errors }, null, 2));
  console.log(JSON.stringify({ results, performance, errors }, null, 2));
} finally { await browser.close(); }
